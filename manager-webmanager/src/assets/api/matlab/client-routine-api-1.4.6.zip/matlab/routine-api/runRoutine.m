function runRoutine(routineName, inPipe, outPipe, ctrlPipe)
    ObjectiveRoutine.createObjectiveRoutine(routineName, inPipe, outPipe, ctrlPipe);
end