namespace java at.enfilo.def.datatype
namespace py def_api

struct DEFDataFrame {
    1: optional string _id = "4164eef5-7369-4c61-8d0d-c95fca246157",
    2: required binary pickledDF
}
