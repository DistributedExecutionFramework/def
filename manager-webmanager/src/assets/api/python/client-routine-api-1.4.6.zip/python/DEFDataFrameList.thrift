namespace java at.enfilo.def.datatype
namespace py def_api

struct DEFDataFrameList {
    1: optional string _id = "a92912cd-3a79-4760-a446-62b8ddc23e89",
    2: required list<binary> pickledDFs
}
